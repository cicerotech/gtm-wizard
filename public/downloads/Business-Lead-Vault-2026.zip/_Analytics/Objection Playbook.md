---
type: analytics_dashboard
auto_refresh: true
category: objections
last_updated: 2026-02-26
---

# Objection Playbook

*Common objections with handling success rates and best responses*

---

## Top Objections (Last 90 Days)

| Objection | Frequency | Handle Rate | Status |
|-----------|-----------|-------------|--------|
| -- | -- | -- | -- |

---

## Best Practices

### Objection: [Example]

**Frequency:** X times  
**Handle Rate:** Y%

**Best Responses:**
1. *Response that worked well*
2. *Another effective response*

---

## Coaching Notes

*Objections with <50% handle rate need training focus*

---

> **Tip:** Review this playbook before important calls.

---
type: analytics_dashboard
auto_refresh: true
category: expansion
last_updated: 2026-02-11
---

# Expansion Opportunities

*Upsell and cross-sell signals from customer conversations*

---

## Hot Opportunities

| Account | Opportunity Type | Signal | Readiness |
|---------|-----------------|--------|-----------|
| -- | -- | -- | -- |

---

## Warm Opportunities

| Account | Opportunity Type | Signal | Next Step |
|---------|-----------------|--------|-----------|
| -- | -- | -- | -- |

---

## Signals by Type

### New Use Cases
*Customers exploring new applications...*

### Additional Users
*Customers wanting to expand user base...*

### New Products
*Interest in other Eudia products...*

---

> **Action:** Prioritize hot opportunities for this quarter.

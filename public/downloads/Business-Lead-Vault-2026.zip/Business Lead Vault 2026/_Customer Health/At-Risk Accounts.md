---
type: analytics_dashboard
auto_refresh: true
category: at_risk
last_updated: 2026-02-13
---

# At-Risk Accounts

*Accounts showing risk indicators from recent calls*

---

## High Risk

| Account | Health Score | Risk Indicators | Last Call |
|---------|--------------|-----------------|-----------|
| -- | -- | -- | -- |

---

## Medium Risk

| Account | Health Score | Risk Indicators | Last Call |
|---------|--------------|-----------------|-----------|
| -- | -- | -- | -- |

---

## Risk Trends

*Accounts with declining sentiment over past 30 days*

---

> **Action:** Prioritize outreach to high-risk accounts.

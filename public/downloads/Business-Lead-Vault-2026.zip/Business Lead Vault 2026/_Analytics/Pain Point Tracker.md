---
type: analytics_dashboard
auto_refresh: true
category: pain_points
last_updated: 2026-02-10
---

# Customer Pain Point Tracker

*Aggregated pain points from customer conversations*

---

## Top Pain Points (Last 30 Days)

| Pain Point | Frequency | Category | Severity |
|------------|-----------|----------|----------|
| -- | -- | -- | -- |

---

## By Category

### Legal
*Pain points related to legal processes...*

### Efficiency
*Pain points related to efficiency/speed...*

### Cost
*Pain points related to budget/cost...*

### Risk
*Pain points related to compliance/risk...*

---

## Example Quotes

*Customer quotes will appear here for reference in sales conversations*

---

> **Tip:** Use these pain points to prepare for customer calls.

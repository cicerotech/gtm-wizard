---
type: analytics_dashboard
auto_refresh: true
category: coaching
last_updated: 2026-02-10
---

# Coaching Insights

*AI-generated coaching recommendations for your team*

---

## Talk Time Analysis

**Optimal Range:** 40-50% rep talk time

| Rep | Talk Ratio | Status |
|-----|------------|--------|
| -- | -- | -- |

---

## Question Quality

**Goal:** >60% open-ended questions

| Rep | Open Question Rate | Trend |
|-----|-------------------|-------|
| -- | -- | -- |

---

## Value Articulation

**Scale:** 0-10

| Rep | Avg Score | Top Area | Focus Area |
|-----|-----------|----------|------------|
| -- | -- | -- | -- |

---

## This Week's Focus

*Coaching recommendations will appear here based on call analysis*

---

> **Note:** Schedule 1:1s with reps showing declining trends.

---
type: analytics_dashboard
auto_refresh: true
refresh_interval: daily
last_updated: 2026-02-05
---

# Team Performance Dashboard

*This note auto-updates with data from the GTM Brain analytics API.*

---

## Team Overview

| Metric | This Week | Trend |
|--------|-----------|-------|
| Calls Analyzed | -- | -- |
| Avg Score | -- | -- |
| Talk Ratio | -- | -- |

---

## Top Performers

*Connect to server to load team data*

---

## Coaching Focus Areas

*Analytics will populate based on call analysis*

---

> **Note:** This dashboard refreshes automatically when you open it.
> Data is aggregated from all analyzed calls in your region.

# Quick Start

Your command center for account intelligence, meeting prep, and deal context.

---

## Getting Started

1. **Enter your email** - Use your @eudia.com email address
2. **Connect Salesforce** (optional) - Enables live account sync
3. **Your accounts load** - Account folders appear in the left sidebar

---

## Two Ways to Access Account Intel

### 📁 Account Folders (Left Sidebar)
Click any account folder to see:
- Meeting notes and transcripts
- Key contacts and roles
- Historical deal context

**Best for:** Browsing account history, reviewing past meetings

### 💬 GTM Brain (Chat Panel)
Click the **message icon** in the ribbon, then ask questions like:
- "What's the latest on [Account]?"
- "Who are the key stakeholders?"
- "What pain points have they mentioned?"

**Best for:** Quick intel lookup, prep questions, deal strategy

> **Tip:** GTM Brain pulls from Slack, calendar, Salesforce, and meeting notes. The more activity on an account, the richer the answers.

---

## The Ribbon Icons

| Icon | What It Does |
|------|--------------|
| 📅 **Calendar** | Today's meetings. Click to refresh. Click a meeting to create notes. |
| 🎤 **Microphone** | Record and transcribe calls with AI. |
| 💬 **Message** | Ask GTM Brain about any account. |
| ⚙️ **Settings** | Configure your email, Salesforce, and timezone. |

---

## Before Your Next Call

1. Open the **Calendar** panel → Click your upcoming meeting
2. Ask GTM Brain: "Prep me for [Account Name]"
3. Review the account folder for recent notes

---

## Refreshing Data

- **Calendar:** Click the ↻ button to fetch live data from Microsoft Graph
- **Accounts:** Press `Cmd+P` → "Sync Salesforce Accounts"

---

## Quick Tips

| Goal | Action |
|------|--------|
| Find an account | Use sidebar folders or ask GTM Brain |
| Prep for a call | Calendar → click meeting → ask GTM Brain |
| See deal history | Open account folder → browse notes |
| Record a meeting | Click microphone → stop when done |

---

## Support

**GTM Hub:** gtm-wizard.onrender.com
**Slack:** #gtm-tools

# Quick Reference

Your sales vault: record meetings, transcribe with AI, sync to Salesforce.

---

## What This Does

- **Transcribes** your customer calls with speaker identification
- **Extracts** next steps, pain points, and MEDDICC data automatically  
- **Syncs** everything to Salesforce and the GTM Hub for meeting prep

---

## Your Daily Workflow

### Before a Call
1. Click the **calendar icon** → find your meeting → click to create a note
2. Review context in GTM Hub's Meeting Prep tab

### During a Call  
1. Click the **microphone icon** to start recording
2. Take any manual notes as needed

### After a Call
1. Click microphone again to stop → AI transcribes in ~30 seconds
2. Next steps auto-populate to your dashboards
3. Note syncs to Salesforce (if enabled)

---

## Key Locations

| Folder | What's There |
|--------|--------------|
| **Accounts/** | One folder per account with notes, contacts, intelligence |
| **Next Steps/** | All action items across every account |
| **_Analytics/** | Team performance, objections, coaching (managers) |
| **_Customer Health/** | At-risk accounts, expansion signals, feature requests |

---

## Sidebar Icons

| Icon | Action |
|------|--------|
| Calendar | View meetings, create notes |
| Microphone | Start/stop recording |
| Message | Ask GTM Brain about current account |

---

## How Data Flows

**Meeting Note** → AI extracts insights → Saved to account folder

↓

**All Next Steps** dashboard aggregates action items across accounts

↓

**GTM Hub** displays context for your next meeting prep

---

## Common Tasks

| Task | How |
|------|-----|
| Ask about an account | Click message icon or `Cmd+P` → "Ask GTM Brain" |
| Refresh accounts | `Cmd+P` → "Sync Salesforce Accounts" |
| Sync note to SF | Add `sync_to_salesforce: true` to note header |

---

## Need Help?

**GTM Hub**: gtm-wizard.onrender.com  
**Settings**: Settings → Community Plugins → Eudia Sync & Scribe  
**Slack**: #gtm-tools

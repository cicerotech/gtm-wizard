# Your Accounts

Your account folders will appear here after you complete the setup wizard.

1. Enter your @eudia.com email
2. Connect to Salesforce
3. Your owned accounts will be imported automatically

Delete this note after setup is complete.

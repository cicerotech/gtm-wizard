---
title: Meeting Notes 4
date: 
account: "Allied Irish Banks plc"
account_id: "001Wj00000mCFs7IAG"
owner: "Nicola Fratini"
sync_to_salesforce: false
clo_meeting: false
source: ""
transcribed: false
---

# Meeting Notes - Allied Irish Banks plc

*Click the microphone icon to transcribe a meeting, or start typing notes.*

## Pre-Call Notes

*Add context, preparation, or questions here*

---

## Meeting Summary

*Transcription will appear here after recording*

---

## Next Steps

- [ ] *Action items will be extracted here*


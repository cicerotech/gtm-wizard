---
type: analytics_dashboard
auto_refresh: true
category: feature_requests
last_updated: 2026-02-26
---

# Feature Requests Tracker

*Feature requests aggregated from customer calls*

---

## Top Requests

| Feature | Customer Count | Priority | Status |
|---------|----------------|----------|--------|
| -- | -- | -- | -- |

---

## By Product Area

### AI Contracting
- ...

### AI Compliance
- ...

### AI M&A
- ...

---

## Customer Quotes

*Selected quotes to share with Product team*

---

> **Tip:** Share this monthly with the Product team.

---
type: next_steps_dashboard
auto_updated: true
last_updated: 2026-02-26
---

# All Next Steps Dashboard

*Last updated: 2026-02-26 8:44 AM*

---

## How This Works

This dashboard automatically aggregates next steps from all your account meetings.

1. **Record a meeting** in any account folder
2. **Transcribe** using the microphone button
3. **Next steps are extracted** by AI and added to the account's Next Steps note
4. **This dashboard updates** to show all accounts' next steps in one view

---

## Your Next Steps

*Complete your first meeting transcription to see next steps here.*

---

## Recently Updated

| Account | Last Meeting | Next Steps |
|---------|--------------|------------|
| *None yet* | - | Complete a meeting transcription |


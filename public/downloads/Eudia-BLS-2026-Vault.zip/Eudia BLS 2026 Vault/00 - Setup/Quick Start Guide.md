# Quick Start Guide

## Step 1: Connect Your Calendar

Click the **📅 Calendar** icon in the left sidebar, then enter your @eudia.com email.

Your calendar syncs automatically via Microsoft 365.

---

## Step 2: Find Your Account

All accounts are pre-loaded in the **Accounts** folder.

Use **Cmd/Ctrl + O** to quick-switch between files.

---

## Step 3: Transcribe a Meeting

1. Open a note for the account
2. Click the **🎙️ Microphone** icon
3. Meeting audio is captured automatically
4. Click **Stop** when finished
5. AI generates the summary

---

## Step 4: Sync to Salesforce

After transcription:
1. Review the AI-generated summary
2. Check the boxes for completed next steps
3. Click **Sync to Salesforce** in settings or use the sidebar icon

---

## Keyboard Shortcuts

| Action | Shortcut |
|--------|----------|
| Start/Stop Transcription | Cmd/Ctrl + Shift + R |
| Open Calendar | Cmd/Ctrl + Shift + C |
| Quick Switch Files | Cmd/Ctrl + O |
| Sync to Salesforce | Cmd/Ctrl + Shift + S |

---

## Troubleshooting

**Calendar shows 404?**
→ Make sure you've entered your @eudia.com email in settings

**Transcription not starting?**
→ Allow microphone access when prompted

**Sync failing?**
→ Check your internet connection and try again in 30 seconds


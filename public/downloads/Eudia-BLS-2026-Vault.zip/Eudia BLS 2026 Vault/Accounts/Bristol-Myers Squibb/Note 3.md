---
title: Meeting Notes 3
date: 
account: "Bristol-Myers Squibb"
account_id: "001Hp00003kIrFkIAK"
owner: "Olivia Jung"
sync_to_salesforce: false
transcribed: false
---

# Meeting Notes - Bristol-Myers Squibb

*Click the microphone icon to transcribe a meeting, or start typing notes.*

## Pre-Call Notes

*Add context, preparation, or questions here*

---

## Meeting Summary

*Transcription will appear here after recording*

---

## Next Steps

- [ ] *Action items will be extracted here*


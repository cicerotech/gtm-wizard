---
title: Meeting Notes 1
date: 
account: "Diageo"
account_id: "001Wj00000Y6VMMIA3"
owner: "Greg MacHale"
sync_to_salesforce: false
transcribed: false
---

# Meeting Notes - Diageo

*Click the microphone icon to transcribe a meeting, or start typing notes.*

## Pre-Call Notes

*Add context, preparation, or questions here*

---

## Meeting Summary

*Transcription will appear here after recording*

---

## Next Steps

- [ ] *Action items will be extracted here*


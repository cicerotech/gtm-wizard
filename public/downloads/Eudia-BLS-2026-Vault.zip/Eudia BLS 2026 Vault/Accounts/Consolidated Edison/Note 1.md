---
title: Meeting Notes 1
date: 
account: "Consolidated Edison"
account_id: "001Hp00003kIrGZIA0"
owner: "Olivia Jung"
sync_to_salesforce: false
transcribed: false
---

# Meeting Notes - Consolidated Edison

*Click the microphone icon to transcribe a meeting, or start typing notes.*

## Pre-Call Notes

*Add context, preparation, or questions here*

---

## Meeting Summary

*Transcription will appear here after recording*

---

## Next Steps

- [ ] *Action items will be extracted here*


---
title: Meeting Notes 3
date: 
account: "Aramark Ireland"
account_id: "001Hp00003kIrEyIAK"
owner: "Conor Molloy"
sync_to_salesforce: false
transcribed: false
---

# Meeting Notes - Aramark Ireland

*Click the microphone icon to transcribe a meeting, or start typing notes.*

## Pre-Call Notes

*Add context, preparation, or questions here*

---

## Meeting Summary

*Transcription will appear here after recording*

---

## Next Steps

- [ ] *Action items will be extracted here*


---
title: Meeting Notes 3
date: 
account: "Citadel"
account_id: "001Wj00000RjuhjIAB"
owner: "Ananth Cherukupally"
sync_to_salesforce: false
transcribed: false
---

# Meeting Notes - Citadel

*Click the microphone icon to transcribe a meeting, or start typing notes.*

## Pre-Call Notes

*Add context, preparation, or questions here*

---

## Meeting Summary

*Transcription will appear here after recording*

---

## Next Steps

- [ ] *Action items will be extracted here*


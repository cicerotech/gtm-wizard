---
title: Meeting Notes 4
date: 
account: "Carta"
account_id: "001Wj00000mosEXIAY"
owner: "Asad Hussain"
sync_to_salesforce: false
transcribed: false
---

# Meeting Notes - Carta

*Click the microphone icon to transcribe a meeting, or start typing notes.*

## Pre-Call Notes

*Add context, preparation, or questions here*

---

## Meeting Summary

*Transcription will appear here after recording*

---

## Next Steps

- [ ] *Action items will be extracted here*


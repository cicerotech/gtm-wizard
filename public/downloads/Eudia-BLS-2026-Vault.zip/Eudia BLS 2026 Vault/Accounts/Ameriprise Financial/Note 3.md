---
title: Meeting Notes 3
date: 
account: "Ameriprise Financial"
account_id: "001Hp00003kIrElIAK"
owner: "Julie Stefanich"
sync_to_salesforce: false
transcribed: false
---

# Meeting Notes - Ameriprise Financial

*Click the microphone icon to transcribe a meeting, or start typing notes.*

## Pre-Call Notes

*Add context, preparation, or questions here*

---

## Meeting Summary

*Transcription will appear here after recording*

---

## Next Steps

- [ ] *Action items will be extracted here*


---
title: Meeting Notes 1
date: 
account: "AES"
account_id: "001Hp00003kIrEOIA0"
owner: "Justin Hills"
sync_to_salesforce: false
transcribed: false
---

# Meeting Notes - AES

*Click the microphone icon to transcribe a meeting, or start typing notes.*

## Pre-Call Notes

*Add context, preparation, or questions here*

---

## Meeting Summary

*Transcription will appear here after recording*

---

## Next Steps

- [ ] *Action items will be extracted here*


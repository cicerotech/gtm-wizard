# Welcome to Your Sales Vault

## Getting Started

When you opened this vault, a **Setup Wizard** should have appeared. If not, go to:
`Settings → Eudia Sync & Scribe → Setup`

### Step 1: Connect Your Calendar
Enter your @eudia.com email to sync your Microsoft 365 calendar.

### Step 2: Connect to Salesforce
Click "Connect to Salesforce" and complete the OAuth flow in the popup.
Your account folders will be automatically imported based on your ownership.

### Step 3: Start Transcribing
- Click the **microphone icon** in the left sidebar during a call
- Or press `Cmd/Ctrl+P` and search for "Transcribe Meeting"

---

## Quick Reference

| Action | How |
|--------|-----|
| View Calendar | Click calendar icon in sidebar |
| New Meeting Note | Click any meeting in calendar |
| Transcribe | Click microphone or Cmd+P → Transcribe |
| Sync to Salesforce | Set `sync_to_salesforce: true` in note |

---

## Need Help?

- **Plugin Settings**: Settings → Eudia Sync & Scribe
- **Keyboard Shortcuts**: Settings → Hotkeys → search "Eudia"

Happy selling! 🎯

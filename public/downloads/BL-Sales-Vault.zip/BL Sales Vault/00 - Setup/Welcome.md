# Welcome to BL Sales Vault

This vault is pre-configured with:
- **266 accounts** from your pipeline, each with 5 note templates
- **AI-powered transcription** for your customer meetings
- **Automatic Salesforce sync** for meeting notes

## Quick Start

1. **Connect your calendar** by clicking the 📅 Calendar icon in the left sidebar
2. **Enter your @eudia.com email** when prompted
3. **Start transcribing meetings** by clicking the 🎙️ microphone icon

## How to Use

### Before a Meeting
1. Find the account folder in the sidebar
2. Open one of the pre-created notes
3. Add any prep notes or questions

### During the Meeting
1. Click the microphone icon to start transcription
2. The status bar shows "Listening..." while capturing audio
3. Click Stop when the meeting ends

### After the Meeting
1. AI generates a structured summary with:
   - Key discussion points
   - MEDDICC signals
   - Next steps (as checkboxes)
2. Click "Sync to Salesforce" to push notes to the account

## Note Properties

Each note has frontmatter properties you can edit:
- **clo_meeting**: Check if this was a CLO (Chief Legal Officer) meeting
- **source**: How the meeting came about. Recommended values:
  - `referral`
  - `cold outreach`
  - `BL sourced`

## Tips

- Use **Cmd/Ctrl + P** → "Transcribe Meeting" for keyboard shortcut
- Notes are organized by account for easy reference
- The calendar view shows upcoming meetings with auto-detected accounts

---

*Need help? Contact your RevOps team.*
